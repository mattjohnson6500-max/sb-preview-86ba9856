# Project: Elm Street Lofts (FICTIONAL SAMPLE)
- Client: Northline Design Studio. Multi-family, 5 stories over podium.
- Amy's role: specifications consultant, CA support. Phase: construction.
- CA log:
  - RFI 012, sealant color at storefront. Answered.
  - RFI 014, sealant joint width at precast panels. Open. Contractor asks to reduce joints from 3/4 in. to 1/2 in.
  - Sub request, roof insulation. Approved.
