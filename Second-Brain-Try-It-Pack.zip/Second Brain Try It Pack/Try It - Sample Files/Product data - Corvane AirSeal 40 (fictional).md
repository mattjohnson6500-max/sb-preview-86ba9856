# Corvane AirSeal 40, fluid-applied air barrier. FICTIONAL SAMPLE DATA, NOT A REAL PRODUCT
Data sheet date: March 2025
| Property | Value | Test method |
|---|---|---|
| Air permeance | 0.0003 cfm/sq ft at 1.57 psf | ASTM E2178 |
| Assembly air leakage | 0.02 cfm/sq ft at 1.57 psf, after conditioning at 12.5 psf | ASTM E2357 |
| Water vapor permeance | 12 perms | ASTM E96, Method B |
| Elongation | 400% | ASTM D412 |
| Service temperature | -40 to 180 deg F | Manufacturer |
Compatible sealants: Corvane CS-200 and listed silicones (see compatibility chart).
Warranty: 10-year material and labor when installed by a Corvane-certified applicator.
