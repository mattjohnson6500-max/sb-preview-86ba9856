# Elm Street Lofts, OAC Meeting #8, Oct 6, 2026 (FICTIONAL SAMPLE)
Attendees: Marcus Webb (Northline), Amy Baker, J. Ortiz (contractor PM), owner's rep.
Decisions:
- Amenity level ceiling grid: 15/16 in. grid, white, as specified.
- Storefront sealant color: match anodized frame (resolves RFI 012).
Action items:
- Amy: review RFI 014 (joint width at precast) and respond by Oct 14.
- Amy: issue hardware sets for amenity level by Oct 20.
- Contractor: submit revised precast joint layout.
Open questions: owner asked about adding card readers at the amenity level fitness room.
