# Brightwall VaporGuard SA, self-adhered air barrier membrane. FICTIONAL SAMPLE DATA, NOT A REAL PRODUCT
Submitted as a substitution for Riverside Branch Library.
Data sheet date: June 2026
| Property | Value | Test method |
|---|---|---|
| Air permeance | 0.0001 cfm/sq ft at 1.57 psf | ASTM E2178 |
| Assembly air leakage | 0.03 cfm/sq ft at 1.57 psf, after conditioning at 6.24 psf | ASTM E2357 (test report summary attached by contractor) |
| Water vapor permeance | 0.1 perms | ASTM E96, Method A |
| Peel adhesion | Not listed | |
Compatible sealants: not listed on data sheet.
Warranty: 10-year material only. Labor excluded.
