# Project: Riverside Branch Library (FICTIONAL SAMPLE)
- Client: Harbor & Vale Architects. Owner: Riverside Public Library District.
- Location: fictional town in Ohio. Jurisdiction code edition: TO VERIFY.
- Amy's role: specifications consultant. Phase: construction documents.
- Air barrier basis of design: Corvane AirSeal 40 (section 07 27 26). Assembly testing to ASTM E2357 required.
- Open issues: meeting room occupant load and egress; substitution request received for air barrier (Brightwall VaporGuard SA).
