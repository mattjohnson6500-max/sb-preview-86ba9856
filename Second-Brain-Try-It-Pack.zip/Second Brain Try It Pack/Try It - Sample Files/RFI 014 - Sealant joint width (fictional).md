# RFI 014, Elm Street Lofts (FICTIONAL SAMPLE)
From: J. Ortiz, contractor PM. Date: Sept 22, 2026.
Question: Spec section 07 92 00 requires 3/4 in. sealant joints at precast panel joints. Panel fabricator proposes 1/2 in. joints to match tolerances shown in their shop drawings. Please confirm 1/2 in. is acceptable.
Attachments referenced: precast shop drawing sheet PC-3 (not included).
