# Client: Northline Design Studio (FICTIONAL SAMPLE)
- Uses a commercial master guide spec, edited by Amy.
- Review comments in their review matrix with a response column.
- Projects with Amy: Elm Street Lofts (construction administration phase).
- Contact: Marcus Webb, project manager.
