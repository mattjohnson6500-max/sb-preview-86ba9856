# Client: Harbor & Vale Architects (FICTIONAL SAMPLE)
- Spec platform: their own Word office master, 3-part format, CSI page format.
- No Related Sections paragraphs. Streamlined language.
- Prefer basis-of-design plus two named equals.
- Comments returned as a marked-up PDF plus a summary email.
- Projects with Amy: Riverside Branch Library (CD phase), Fairview Community Center (SD/DD).
- Contact: Priya Lund, project architect.
