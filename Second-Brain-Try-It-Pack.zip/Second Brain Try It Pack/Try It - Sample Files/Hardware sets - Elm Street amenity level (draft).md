# Hardware sets, amenity level, Elm Street Lofts. FICTIONAL DRAFT FOR REVIEW
Set 01, Fitness room entry (door 201), 90-minute rated pair:
- Continuous hinges, Lakeshore CH200
- Mortise lock, Lakeshore Series 9, storeroom function
- Closer, surface mounted, parallel arm
- Coordinators and flush bolts
Set 02, Lounge to corridor (door 204), single, non-rated:
- Butt hinges
- Mortise lock, classroom function
- Wall stop
Note from architect: owner may add card reader at door 201.
