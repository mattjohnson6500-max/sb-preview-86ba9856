# Lessons (FICTIONAL SAMPLE)
What Amy has taught the second brain so far. Apply these before drafting.

- [all] Record the test method next to every performance value.
- [all] Write in streamlined imperative language. No "shall."
- [client: Harbor & Vale] Remove Related Sections paragraphs.
- [client: Northline] Review comments go in their matrix: sheet, detail, comment, response column.
- [meeting notes] List Amy's action items first.
- [door hardware] Always flag electrified hardware for coordination with access control.
- [section 08 71 00] List approved equals alphabetically.
- [email] Keep emails short. Sign off with first name only.
- [substitution review] Put warranty differences in their own row.
