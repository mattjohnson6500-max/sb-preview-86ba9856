TRY YOUR SECOND BRAIN WITH SAMPLE DATA (about 5 minutes)

Everything in this pack is FICTIONAL: made-up clients, projects and products. It lets you chat with a working demo in your own Claude account before setting up the real thing.

1. Go to claude.ai and sign in with your own Claude account (Pro or higher).
2. In the left sidebar, click Projects, then create a new project. Name it "Second Brain Demo."
3. Open the file "Project Instructions (paste this).txt", copy all of it, and paste it into the project's instructions box.
4. Add all the files from the "Try It - Sample Files" folder to the project's files (drag them in).
5. Start a chat in the project and say "Hi." Then try the ideas in "Things to try.txt."

If any button looks different, take a screenshot and drop it into a regular Claude chat, and ask where to click.

What's different in the real version: everything lives in a folder on your computer, Claude files new documents for you, a dashboard tracks your requests, and lessons are saved permanently.
