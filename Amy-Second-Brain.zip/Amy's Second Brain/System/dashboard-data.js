// Kept up to date by Claude. Read by Dashboard.html. Please don't edit by hand.
window.BRAIN_DATA = {
  owner: "Amy Baker",
  updated: "2026-10-28",
  requests: [],
  brain: [],
  lessons: []
};
