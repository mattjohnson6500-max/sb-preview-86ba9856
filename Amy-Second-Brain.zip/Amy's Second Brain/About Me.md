# About Me — Amy Baker

NOT STARTED

(Claude: this profile fills in gradually through real work. See CLAUDE.md, Section 3. Items marked *(public — unconfirmed)* came from Amy's website and LinkedIn. Confirm them when they come up naturally, and remove the marker once she does.)

## Role and firm
- Licensed architect and independent specifications consultant *(public — unconfirmed)*
- Amy Baker Architect, Royal Oak, Michigan *(public — unconfirmed)*
- 20+ years of experience *(public — unconfirmed)*
- AIA, CSI, CDT, SCIP, LEED AP; Lawrence Technological University *(public — unconfirmed)*

## Lines of work
- Project Manuals for architect clients, about $300K–$300M *(public — unconfirmed)*
- Guide specs for manufacturers, reps and trade organizations *(public — unconfirmed)*
- Code analysis, life safety plans, third-party drawing reviews, CDs, construction administration *(public — unconfirmed)*

## Interests
- Spec writing, code studies, door hardware schedules, construction administration, building enclosure detailing; education and mentoring *(public — unconfirmed)*

## Spec tools and format

## Clients (confirmed)

## Active projects (confirmed)

## People I work with (confirmed)

## Standards, codes and jurisdictions

## How I like answers

## How I write emails (my voice)

---

## Open questions
(Claude: ask only when it naturally helps the task at hand, one at a time, or all of them if Amy says "interview me." Remove each one once it's answered.)

- Her site says her spec practice combined with WDEO, and that she and David Oglesby have 50+ years of specifying experience between them. How do they work together? Should his notes and decisions count like hers, or should he just be a colleague contact?
- Her site lists spec work for Marlon Blackwell Architects, Stantec, Tinker Ma, The Collaborative, McIntosh Poris, Ethos Architects and Olson Kundig. Which are current clients?
- Her site shows Elementa Brush Park, The Claire, 1315 Broadway, Milk & Froth and Detroit Public Theater. Which are active, and which are past work?
- Which spec platforms does she use, and do they vary by client?
- Which states and code editions come up most right now?
