# Outputs
Drafts, comparison tables, emails and spec drafts Claude makes for you.
