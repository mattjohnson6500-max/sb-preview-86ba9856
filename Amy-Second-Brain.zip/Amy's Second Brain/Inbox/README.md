# Inbox
Drop new things here: product data, PDFs, meeting notes, photos, saved emails. Then tell Claude: "File my inbox."
