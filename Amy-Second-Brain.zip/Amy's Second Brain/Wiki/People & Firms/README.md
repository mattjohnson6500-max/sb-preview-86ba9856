# People & Firms
Pages Claude keeps about people & firms.
