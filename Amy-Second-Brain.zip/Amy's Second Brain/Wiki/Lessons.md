# Lessons — what Amy has taught me

Every correction Amy makes that should change future work goes here, newest first. Claude reads this before drafting anything.

Format: `- YYYY-MM-DD — [scope] Lesson. (from request R-0000)`
