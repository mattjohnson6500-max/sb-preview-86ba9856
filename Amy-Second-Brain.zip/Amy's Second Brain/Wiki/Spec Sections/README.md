# Spec Sections
Pages Claude keeps about spec sections.
