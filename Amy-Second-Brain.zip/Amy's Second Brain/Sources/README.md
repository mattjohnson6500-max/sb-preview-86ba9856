# Sources
Your original files, kept exactly as they came. Claude reads these but never changes or deletes them.
