# Start Here, Amy

This folder is your second brain. You don't need to organize anything in it. Claude does that, but only when you ask, and only after you say OK.

**To use it:** open the Claude app with this folder connected (see the setup guide) and say:

> **"Open my second brain."**

**To see everything at a glance:** double-click **Dashboard.html**. It opens in your web browser and shows what you've asked for and everything your second brain knows.

**The ground rules, in short**
1. It's yours alone. Matt set it up but can't see or touch it.
2. It only does what you ask, and checks with you before changing anything.
3. Expect its first try to be wrong. Your corrections teach it.
4. The goal is a draft you approve with no changes.
5. You're the professional. Final judgment is always yours.
6. You own it, with no strings. Want it to work differently or do something new? Just ask.
7. Stuck? Ask "How do I…?" for step-by-step help, or drop a screenshot into the chat.

You don't need to edit any files yourself, including `CLAUDE.md` (Claude's rulebook) and the `System` folder. To change anything, just tell Claude.
